#km, same as geopack
RE = 6371.2
if __name__ == "__main__":
    print("unit test here")