#this is GENA date process packet
#strat from L2 csv data to ena instance and do analysis
